// Arguments passed into this controller can be accessed via the `$.args` object directly or:
var args = $.args;
$.lbltitle.text=args.title;
//$.lblTitle.objName=args.country_id;
$.row.args=args; 