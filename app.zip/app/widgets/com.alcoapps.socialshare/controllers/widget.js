function share(args){
	require(WPATH('com.alcoapps.socialshare')).share(args);
}

exports.share = share;