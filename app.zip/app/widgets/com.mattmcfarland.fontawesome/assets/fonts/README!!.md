# But wait, there's more!

To ensure compatability with Android please copy(dont delete) this fonts folder to your app assets directory.

The resulted path should be `app/assets/fonts/FontAwesome.ttf`